<?php

use App\Http\Controllers\sufragioController;
use App\Http\Controllers\homeController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', homeController::class);

Route::get('inicio', [sufragioController::class, 'index'])->name('sufragio.index');
Route::get('login', [sufragioController::class, 'login'])->name('sufragio.login');
Route::get('register', [sufragioController::class, 'register'])->name('sufragio.register');
Route::get('resultados', [sufragioController::class, 'resultados'])->name('sufragio.resultados');
Route::get('votar', [sufragioController::class, 'votar'])->name('sufragio.votar');
