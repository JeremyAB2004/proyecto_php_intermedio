@extends('layouts.plantillaLogin')

@section('title', 'Ingresar')

@section('sidebar')
    @parent
    <div class="text-center">
        <p class="h1">Ingresar</p>
    </div>
@endsection

@section('content')

    <style>
        #divLogin{
            max-width: 450px;
            margin:auto;
            background-color: #7f92ad;
            border-radius: 8px;
        }
    </style>

    <div id="divLogin" class="p-3 pt-5">
        <form id="loginform">
            <label for="cedulaLogin" class="form-label">Porfavor, ingrese su identificación</label>
            <input id="cedulaLogin" type="text" class="form-control mb-3" name="cedulaLogin" placeholder="Número de identificación" required="">

            <label for="passwordLogin" class="form-label">Porfavor, ingrese su contraseña</label>
            <input id="passwordLogin" type="password" class="form-control" name="passwordLogin" placeholder="Contraseña" required="">

            <button type="button" class="btn btn-dark mt-4" title="Ingresar" name="btnIngresar">Ingresar</button>

            <div class="mt-4">
                <a href="" class="text-light">¿No está registrado (a)?</a>
            </div>
        </form>
    </div>
@endsection
