@extends('layouts.plantilla')

@section('title', 'Resultados Elecciones 2022')

@section('sidebar')
    @parent
    <div class="container-sm">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Inicio</a></li>
                <li class="breadcrumb-item active" aria-current="page">Resultados</li>
            </ol>
        </nav>
    </div>
@endsection

@section('content')
    <h1>Resultados de las elecciones presidenciales 2022</h1>
@endsection
