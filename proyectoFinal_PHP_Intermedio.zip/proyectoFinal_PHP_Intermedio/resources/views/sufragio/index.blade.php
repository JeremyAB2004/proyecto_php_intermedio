@extends('layouts.plantilla')

@section('title', 'Elecciones Costa Rica')

@section('sidebar')
    @parent
    <div class="container-sm">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">Inicio</li>
            </ol>
        </nav>
    </div>
@endsection

@section('content')
    <h1>Elecciones presidenciales 2022</h1>
@endsection
