@extends('layouts.plantilla')

@section('title', 'Votar Elecciones 2022')

@section('sidebar')
    @parent
    <div class="container-sm">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Inicio</a></li>
                <li class="breadcrumb-item active" aria-current="page">Votar</li>
            </ol>
        </nav>
    </div>
@endsection

@section('content')
    <h1>Ingresar mi voto</h1>

    <p class="text-secondary">Aquí se validará si el usuario está logueado</p>
@endsection
