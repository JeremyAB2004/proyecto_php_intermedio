<?php $__env->startSection('title', 'Ingresar'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>
    <div class="text-center">
        <p class="h1">Ingresar</p>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <style>
        #divLogin{
            max-width: 450px;
            margin:auto;
            background-color: #7f92ad;
            border-radius: 8px;
        }
    </style>

    <div id="divLogin" class="p-3 pt-5">
        <form id="loginform">
            <label for="cedulaLogin" class="form-label">Porfavor, ingrese su identificación</label>
            <input id="cedulaLogin" type="text" class="form-control mb-3" name="cedulaLogin" placeholder="Número de identificación" required="">

            <label for="passwordLogin" class="form-label">Porfavor, ingrese su contraseña</label>
            <input id="passwordLogin" type="text" class="form-control" name="passwordLogin" placeholder="Contraseña" required="">

            <button type="button" class="btn btn-dark mt-4" title="Ingresar" name="btnIngresar">Ingresar</button>

            <div class="mt-4">
                <a href="" class="text-light">¿No está registrado (a)?</a>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantillaLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectoFinal_PHP_Intermedio\resources\views/sufragio/login.blade.php ENDPATH**/ ?>