<?php $__env->startSection('title', 'Registrarme'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('sidebar'); ?>
    <div class="text-center">
        <p class="h1">Registrarme</p>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <style>
        #divLogin{
            max-width: 450px;
            margin:auto;
            background-color: #7f92ad;
            border-radius: 8px;
        }
    </style>

    <div id="divLogin" class="p-3 pt-5">
        <form id="loginform">
            <label for="cedulaRegister" class="form-label">Porfavor, ingrese su identificación</label>
            <input id="cedulaRegister" type="text" class="form-control mb-3" name="cedulaRegister" placeholder="Número de identificación" required="">

            <label for="nombreCompletoRegister" class="form-label">Porfavor, ingrese su nombre completo</label>
            <input id="nombreCompletoRegister" type="text" class="form-control mb-3" name="nombreCompletoRegister" placeholder="Número de identificación" required="">

            <label for="passwordRegister" class="form-label">Porfavor, ingrese su contraseña</label>
            <input id="passwordRegister" type="text" class="form-control mb-3" name="passwordRegister" placeholder="Contraseña" required="">

            <label for="passwordConfirmationRegister" class="form-label">Porfavor, confirme su contraseña</label>
            <input id="passwordConfirmationRegister" type="text" class="form-control" name="passwordConfirmationRegister" placeholder="Confirmar contraseña" required="">

            <button type="button" class="btn btn-dark mt-4" title="Ingresar" name="btnRegistrar">Registrarme</button>

            <div class="mt-4">
                <a href="" class="text-light">Ingresar</a>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantillaLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectoFinal_PHP_Intermedio\resources\views/sufragio/register.blade.php ENDPATH**/ ?>